package com.krrtk.RowSytem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RowSytemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RowSytemApplication.class, args);
	}

}
